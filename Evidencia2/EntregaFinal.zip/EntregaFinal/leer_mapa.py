# Abre el archivo y lee las líneas
with open('mapa.txt', 'r') as file:
    lineas = file.readlines()

# Elimina los saltos de línea y los caracteres de tabulación (\t), convierte cada línea en una lista de caracteres
lista_de_listas = [list(filter(lambda x: x != '\n' and x != '\t', linea.strip())) for linea in lineas]

# Muestra la lista de listas resultante
for lista in lista_de_listas:
    print(lista)